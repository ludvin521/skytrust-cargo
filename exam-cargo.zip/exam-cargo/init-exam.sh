#!/usr/bin/env bash
set -euo pipefail
echo "=== Initialisation de l'examen PKI-ADV-11 : SkyTrust Cargo ==="
echo ""
read -rp "Votre prénom : " prenom
read -rp "Votre nom    : " nom
prenom_slug="${prenom,,}"
nom_slug="${nom,,}"
prenom_slug="${prenom_slug// /-}"
nom_slug="${nom_slug// /-}"
DOSSIER="examen-${nom_slug}-${prenom_slug}"
mkdir -p \
  "$DOSSIER/phase1/screenshots" \
  "$DOSSIER/phase2" \
  "$DOSSIER/phase3/partieA" \
  "$DOSSIER/phase3/partieB"
touch "$DOSSIER/rapport.md"
echo ""
echo "✅ Arborescence créée : $DOSSIER/"
find "$DOSSIER" | sort
