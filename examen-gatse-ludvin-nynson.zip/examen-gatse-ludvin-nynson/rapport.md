# Rapport d'examen — PKI-ADV-11 : SkyTrust Cargo

**Etudiant** : Ludvin GATSE NYNSON

---

## Phase 1 — Deploiement de la hierarchie Cargo

Fichiers deposes dans phase1/ :
- cargo-root.pem — certificat Root Cargo
- cargo-issuing.pem — certificat Issuing Cargo
- verify.txt — sortie openssl verify (resultat : OK)
- cargo-root.crl — CRL initiale Root Cargo
- cargo-issuing.crl — CRL initiale Issuing Cargo

### 1.1 Ecarts lab vs production

#### Bloc A — Derogations autorisees

| # | Hypothese | Exigence CP | Attendu en production | Impact en lab |
|---|-----------|-------------|-----------------------|---------------|
| A1 | Instance EJBCA unique (Root + Issuing coexistent) | CP Root §1 : separation d'instance Root et Issuing sur deux instances distinctes | Deux instances separees : Root offline air-gapped, Issuing online 24/7 | Root exposee en continu ; compromission host = compromission des deux niveaux |
| A2 | Resolution DNS pki.cargo.skytrust.local via localhost | CP Root §2 / CP Issuing §2 — URLs publiees http://pki.cargo.skytrust.local/ | DNS interne resolvable + reverse-proxy HTTP dedie | Relying parties hors poste de lab ne peuvent valider la chaine |
| A3 | SoftHSM en lieu et place d'un HSM materiel | CP Root §5 / CP Issuing §5 : HSM materiel certifie FIPS 140-2 Level 3 | HSM materiel certifie FIPS 140-2 L3 (Thales Luna, Utimaco) | Cle privee exposee dans le volume Docker en clair |
| A4 | Auto-activation du token crypto Root incluse | CP Root §5 : activation HSM Root par quorum M-of-N officers, auto-activation interdite | HSM Root active uniquement lors des ceremonies M-of-N | Root exploitable par tout attaquant ayant acces au conteneur |

#### Bloc B — Ecarts supplementaires identifies

| # | Exigence CP | Realite en lab | Attendu en production | Impact |
|---|-------------|----------------|-----------------------|--------|
| B1 | CP Root §5 : dual-control Root — 2 operateurs + 1 temoin RSSI + 1 scribe, PV signe | Root CA creee par une seule personne sans ceremonie formelle ni PV | Ceremonie documentee avec quorum M-of-N, PV signe | Aucune preuve d'integrite de la creation de la Root |
| B2 | CP Root §4 : CRL Root publiee annuellement 366j max | CRL Root configuree avec periode 24h | Periode CRL Root = 366 jours | Ecart de periode acceptable en lab pour les tests |
| B3 | CP Issuing §2 : OCSP sur URL http://pki.cargo.skytrust.local/ocsp | OCSP sur http://localhost:8081/ejbca/publicweb/status/ocsp | Repondeur OCSP sur URL publique avec nom DNS dedie | Certificats pointent vers URL localhost non accessible exterieurement |
| B4 | CP Root §2 / CP Issuing §2 : CDP et AIA dans les certificats | Certificats emis sans CDP ni AIA configures | CDP et AIA dans chaque certificat pointant vers URLs de publication | Sans CDP/AIA, les relying parties ne peuvent pas verifier la revocation |
| B5 | CP Issuing §3 : CN=FQDN, OU=Cargo, O=SkyTrust Aviation, C=FR obligatoires | DN emis : CN=tracker-001.cargo.skytrust.local sans OU ni O ni C | DN complet avec toutes les composantes | Non-conformite au nommage CP — identite incomplete |
| B6 | CP Issuing §6 : profil dedie CP_Cargo_TLS avec extensions metier | Profil ENDUSER generique utilise au lieu de CP_Cargo_TLS | CP_Cargo_TLS avec EKU, KU, CDP, AIA configures | Profil ENDUSER ne garantit pas les extensions metier requises |
| B7 | CP Root §7.1 : Basic Constraints Root avec pathLen:1 | pathLen non configure — Basic Constraints : CA:TRUE sans pathLen | Basic Constraints : critical, CA:TRUE, pathLen:1 | Possibilite de creer des Issuing CA supplementaires non autorisees |
| B8 | CP Issuing §8 : integrite des journaux par chainages cryptographique | Logs EJBCA non proteges en integrite (configuration par defaut) | Activer IntegrityProtectedDevice dans EJBCA | Logs peuvent etre alteres sans detection |

### 1.2 Mapping CP vers configuration EJBCA

| # | Exigence CP | Implementation EJBCA | Preuve |
|---|-------------|----------------------|--------|
| 1 | CP Root §6 : RSA 4096 bits pour la Root | Crypto Token Cargo-RootCA-Token, alias cargoRootKey RSA 4096 sur SoftHSM | ejbca.sh cryptotoken listkeys : cargoRootKey RSA 4096 |
| 2 | CP Root §6 : SHA-256 avec RSA | Parametre -s SHA256WithRSA lors de ca init | openssl x509 : Signature Algorithm sha256WithRSAEncryption |
| 3 | CP Root §4 : duree de vie Root 20 ans | -v 7300 lors de ca init | notBefore May 3 2026, notAfter Apr 28 2046 |
| 4 | CP Root §4 : duree de vie Issuing 10 ans maximum | -v 3650 lors de ca init Issuing | notBefore May 3 2026, notAfter Apr 30 2036 |
| 5 | CP Issuing §6 : RSA 3072 bits minimum pour l'Issuing | Crypto Token Cargo-IssuingCA-Token, alias cargoIssuingKey2 RSA 3072 | ejbca.sh cryptotoken listkeys : cargoIssuingKey2 RSA 3072 |
| 6 | CP Root §1 : architecture Root vers Issuing vers end-entity 2 niveaux | Issuing CA creee avec --signedby 1054481377 (ID Root CA) | listcas : Issuing Signed by 1054481377 ; openssl verify : cargo-issuing.pem OK |
| 7 | CP Root §7.3 : CRL Root format X.509v2 signee SHA-256 | EJBCA genere automatiquement la CRL lors de ca init | openssl crl -in cargo-root.crl -inform DER : Issuer CN=SkyTrust Cargo Root CA |
| 8 | CP Issuing §7.3 : CRL Issuing publiee toutes les 24h | CRL Issuing configuree dans EJBCA avec periode 24h | openssl crl : Next Update +24h |
| 9 | CP Issuing §4 : revocation motif keyCompromise publiee immediatement | ejbca.sh ra revokecert reason=1 + ca createcrl | CRL contient serial 2EC4274E avec Key Compromise |
| 10 | CP Issuing §4 : OCSP temps reel | Repondeur OCSP EJBCA natif sur /ejbca/publicweb/status/ocsp | openssl ocsp : tracker-002 revoked Reason keyCompromise immediat |

### 1.3 Remarques

Configuration realisee integralement en ligne de commande (CLI EJBCA + OpenSSL + Docker). Le profil ROOTCA EJBCA ne permettant pas de configurer pathLen via CLI dans cette version (9.3.7 CE), la contrainte de profondeur n'a pas pu etre appliquee — ecart documente en B7. L'utilisation du profil ENDUSER generique au lieu du profil metier CP_Cargo_TLS est due a une incompatibilite de configuration du profil End Entity en lab.

---

## Phase 2 — Cycle de vie automatise des certificats Cargo

Fichiers deposes dans phase2/ :
- tracker-001.pem — certificat tracker-001.cargo.skytrust.local
- tracker-001.csr — CSR tracker-001 (cle privee restee cote demandeur)
- tracker-002.pem — certificat tracker-002.cargo.skytrust.local avant revocation
- cargo-issuing-postrevoke.crl — CRL apres revocation de tracker-002
- ocsp-tracker-001.txt — reponse OCSP tracker-001 : good
- ocsp-tracker-002.txt — reponse OCSP tracker-002 : revoked

### Elements de configurations crees pour ce besoin

- Certificate Profile CP_Cargo_TLS : profil end-entity dedie aux endpoints Cargo TLS, associe a SkyTrust Cargo Issuing CA.
- End Entity Profile EEP_Cargo_TLS : profil end entity avec Default CA Issuing Cargo, Token User Generated.
- End entities crees via CLI : tracker-001.cargo.skytrust.local et tracker-002.cargo.skytrust.local avec token USERGENERATED.
- Emission via ejbca.sh createcert avec CSR fournie en argument — la CA ne voit jamais la cle privee (conformite CP Issuing §6).

### Justifications cles

La cle privee de chaque tracker est generee localement (openssl genrsa) et ne transite jamais vers EJBCA, conformement a la CP Issuing §6. La revocation de tracker-002 avec motif keyCompromise (reason=1) a ete realisee via CLI et la CRL regeneree immediatement. Le repondeur OCSP EJBCA natif permet une verification en temps reel : tracker-002 passe a revoked immediatement, tracker-001 reste good.

### Remarques

Le script enroll-cargo.sh fourni n'a pas pu etre utilise directement car la REST API necessite une configuration d'authentification mTLS non disponible dans l'environnement de lab. L'emission a ete realisee via la CLI EJBCA qui produit le meme resultat fonctionnel.

---

## Phase 3 — Integrations metier

### Partie A — Portail de suivi cargo protege par mTLS

Fichiers deposes dans phase3/partieA/ :
- nginx.conf — configuration nginx avec mTLS active
- serveur-cargo.pem — certificat portal.cargo.skytrust.local
- client-cargo.pem — certificat partenaire.cargo.skytrust.local
- test-ok.txt — trace acceptation certificat client Cargo valide HTTP 200
- test-sans-cert.txt — trace rejet aucun certificat HTTP 400
- test-autre-pki.txt — trace rejet certificat autre PKI HTTP 400

#### 3.A.1 Elements de configurations de la PKI crees

- Certificat serveur portal.cargo.skytrust.local emis par SkyTrust Cargo Issuing CA, RSA 3072, SAN DNS.
- Certificat client partenaire.cargo.skytrust.local emis par SkyTrust Cargo Issuing CA, RSA 3072.
- Configuration nginx sur port 9443 avec ssl_verify_client on et ssl_client_certificate pointant vers la chaine Issuing + Root Cargo.

#### 3.A.2 Justifications cles

Le mTLS est configure avec ssl_verify_client on — nginx exige un certificat client valide signe par la chaine Cargo. Les trois scenarios sont demontres : acces autorise avec certificat Cargo valide (HTTP 200 + CN affiche), refus sans certificat (HTTP 400 No required SSL certificate was sent), refus avec certificat d'une autre PKI (HTTP 400 The SSL certificate error). Le fichier ssl_client_certificate contient la chaine complete Issuing + Root pour permettre la validation de tous les certificats emis par la PKI Cargo.

#### 3.A.3 Remarques

Le port utilise est 9443 au lieu de 443 car le port 443 est occupe par l'instance EJBCA principale des labs et le port 8443 par l'instance EJBCA exam. Ecart documente sans impact fonctionnel en lab.

---

### Partie B — Signature des manifestes cargo

Fichiers deposes dans phase3/partieB/ :
- manifeste-signe.p7s — signature CMS/CAdES du manifeste format DER
- manifeste.tsq — requete de timestamp SHA-256 CAdES-T
- verify.txt — trace verification : CMS Verification successful
- manifeste-verifie.json — contenu extrait apres verification
- signataire.pem — certificat du signataire

#### 3.B.1 Elements de configurations de la PKI crees

- Certificat signataire signataire.cargo.skytrust.local emis par SkyTrust Cargo Issuing CA, profil ENDUSER, RSA 3072.
- Signature CMS realisee avec openssl cms -sign en SHA-256, format DER, mode nodetach (donnees incluses dans le fichier signe).
- Requete timestamp generee avec openssl ts -query -sha256 pour constituer le composant T de CAdES-T.

#### 3.B.2 Elements pour prouver la conformite de la signature

La verification avec openssl cms -verify -CAfile cargo-root.pem retourne CMS Verification successful et restitue le manifeste original intact. La chaine de confiance complete Root vers Issuing vers Signataire est verifiee. Le fichier manifeste-verifie.json contient le manifeste CARGO-2026-04-21-SK741 identique a l'original, prouvant l'integrite des donnees signees.

#### 3.B.3 Justifications cles

La signature CAdES-BES (CMS avec certificat embarque) est realisee avec SHA-256 conformement a la CP Issuing §6. La requete de timestamp constitue le composant -T de CAdES-T — en production, cette requete serait soumise a un TSA qualifie pour obtenir un jeton de temps opposable. Les certificats emis sous cette CP supportent des signatures electroniques avancees (AdES) conformement a CP Issuing §9 — non qualifiees QES car l'Issuing n'est pas un QTSP.

#### 3.B.4 Remarques

Le niveau CAdES-T complet necessite un TSA externe accessible. En lab isole, la requete TSQ est generee mais le jeton de reponse TSR n'est pas disponible. Cet ecart est documente sans impact sur la demonstration du mecanisme de signature.

---

## Phase 4 — Audit du dossier PKI de NordAir Technical

### 4.1 Rapport d'ecart NordAir Technical

| # | Localisation | Constat | Exigence / reference | Severite |
|---|--------------|---------|----------------------|----------|
| 1 | Doc A + Doc B | Validite Issuing 38 ans 2026-2064 avec cle RSA-2048 | ANSSI RGS B1 : RSA-2048 non recommande au-dela de 2030 | Critique |
| 2 | Doc A + Doc C | Ceremonie Root avec un seul operateur present, Operateur 2 absent, Temoin audit absent | CP Cargo Root §5 : dual-control minimum 2 operateurs + 1 temoin RSSI + 1 scribe | Critique |
| 3 | Doc C | Cle Issuing generee hors HSM via openssl genrsa sur serveur de signature | CP Cargo Root §5/§6 + CP Issuing §5 : cle dans HSM FIPS 140-2 L3, ne sort jamais du perimetre HSM | Critique |
| 4 | Doc A + Doc C | Export PKCS#12 complet cle privee + certificat + chaine avec mot de passe oral | CP Cargo Issuing §5 : cle privee Issuing ne sort jamais du HSM | Critique |
| 5 | Doc B | Key Usage Issuing inclut Digital Signature et Key Encipherment en plus de Certificate Sign et CRL Sign | CP Cargo Root §7.2 : Key Usage Issuing restreint aux seuls usages necessaires a la fonction d'Issuing | Majeur |
| 6 | Doc B | Pas de contrainte pathlen sur le certificat Issuing, Basic Constraints CA:TRUE sans pathlen:0 | CP Cargo Root §7.2 : Basic Constraints doit interdire toute emission de sous-intermediaire pathlen:0 | Majeur |
| 7 | Doc D | Conservation des journaux 2 ans glissants seulement, purge automatique a 730 jours | CP Cargo §8 : conservation 6 ans minimum exigence RGS | Majeur |
| 8 | Doc A + Doc D | Administrateur PKI unique khalvorsen, toutes les operations realisees par une seule personne | CP Cargo Root §5 : dual-control operationnel, toute revocation manuelle requiert validation d'un second operateur | Majeur |
| 9 | Doc D + Doc A | Aucun mecanisme d'integrite des journaux mentionne | CP Cargo §8 : chainages cryptographique ou signature d'entree actives, EJBCA IntegrityProtectedDevice | Modere |

### 4.2 Justifications cles

Les ecarts les plus critiques concernent la securite des cles privees : la cle Issuing est generee hors HSM et stockee en PKCS#12 avec mot de passe oral (ecarts 3 et 4), ce qui annule completement la protection apportee par le HSM Root. La ceremonie incomplete (ecart 2) signifie qu'aucun controle independant n'a ete exerce lors de la creation de la Root CA. La validite de 38 ans avec RSA-2048 (ecart 1) est particulierement preoccupante car la cle sera cryptographiquement vulnerable bien avant l'expiration du certificat. L'absence de separation des devoirs (ecart 8) et d'integrite des logs (ecart 9) empeche toute detection d'actions frauduleuses de l'administrateur unique.

### 4.3 Remarques Phase 4

L'analyse se base sur les documents A a D fournis. Les ecarts identifies sont croises entre plusieurs documents pour maximiser la pertinence. La reference principale utilisee est la CP Cargo SkyTrust implementee dans cet examen, completee par les principes generaux RFC 3647 et RGS.
